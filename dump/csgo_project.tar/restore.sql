--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE csgo_project;
--
-- Name: csgo_project; Type: DATABASE; Schema: -; Owner: comacrae
--

CREATE DATABASE csgo_project WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en-US';


ALTER DATABASE csgo_project OWNER TO comacrae;

\connect csgo_project

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: etl; Type: SCHEMA; Schema: -; Owner: comacrae
--

CREATE SCHEMA etl;


ALTER SCHEMA etl OWNER TO comacrae;

--
-- Name: players; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA players;


ALTER SCHEMA players OWNER TO postgres;

--
-- Name: teams; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA teams;


ALTER SCHEMA teams OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: playerstat_source1_extract; Type: TABLE; Schema: etl; Owner: postgres
--

CREATE TABLE etl.playerstat_source1_extract (
    idx integer,
    name character varying(255),
    country character varying(255),
    teams character varying(255),
    total_maps integer,
    total_rounds integer,
    kd_diff integer,
    kd numeric(4,2),
    rating numeric(4,2)
);


ALTER TABLE etl.playerstat_source1_extract OWNER TO postgres;

--
-- Name: playerstat_source1_transform; Type: TABLE; Schema: etl; Owner: postgres
--

CREATE TABLE etl.playerstat_source1_transform (
    player character varying(255),
    country character varying(255),
    teams text,
    total_maps integer,
    total_rounds integer,
    kd_diff integer,
    kd numeric(4,2),
    rating numeric(4,2)
);


ALTER TABLE etl.playerstat_source1_transform OWNER TO postgres;

--
-- Name: playerstat_source2_extract; Type: TABLE; Schema: etl; Owner: postgres
--

CREATE TABLE etl.playerstat_source2_extract (
    nick character varying(255),
    country character varying(255),
    stats_link character varying(255),
    teams character varying(255),
    maps_played integer,
    rounds_played integer,
    kd_difference integer,
    kd_ratio numeric(4,2),
    rating numeric(4,2),
    total_kills integer,
    headshot_percentage numeric(4,2),
    total_deaths integer,
    grenade_damage_per_round numeric(4,2),
    kills_per_round numeric(4,2),
    assists_per_round numeric(4,2),
    deaths_per_round numeric(4,2),
    teammate_saved_per_round numeric(4,2),
    saved_by_teammate_per_round numeric(4,2),
    kast numeric(4,2),
    impact numeric(4,2)
);


ALTER TABLE etl.playerstat_source2_extract OWNER TO postgres;

--
-- Name: playerstat_source2_transform; Type: TABLE; Schema: etl; Owner: postgres
--

CREATE TABLE etl.playerstat_source2_transform (
    player character varying(255),
    country character varying(255),
    teams text,
    maps_played integer,
    rounds_played integer,
    kd_difference integer,
    kd_ratio numeric(4,2),
    rating numeric(4,2),
    total_kills integer,
    headshot_percentage numeric(4,2),
    total_deaths integer,
    grenade_damage_per_round numeric(4,2),
    kills_per_round numeric(4,2),
    assists_per_round numeric(4,2),
    deaths_per_round numeric(4,2),
    teammate_saved_per_round numeric(4,2),
    saved_by_teammate_per_round numeric(4,2),
    kast numeric(4,2),
    impact numeric(4,2)
);


ALTER TABLE etl.playerstat_source2_transform OWNER TO postgres;

--
-- Name: playerstat_source3_extract; Type: TABLE; Schema: etl; Owner: comacrae
--

CREATE TABLE etl.playerstat_source3_extract (
    player_id integer NOT NULL,
    nickname character varying(255),
    real_name character varying(255),
    age integer,
    country character varying(255),
    current_team character varying(255),
    teams text,
    total_kills integer,
    total_deaths integer,
    headshot_percentage character varying(7),
    damage_per_round numeric(6,2),
    grenade_dmg_per_round numeric(6,2),
    maps_played integer,
    rounds_played integer,
    kills_per_death numeric(6,2),
    kills_per_round numeric(6,2),
    assists_per_round numeric(6,2),
    deaths_per_round numeric(6,2),
    saved_by_teammate_per_round numeric(6,2),
    saved_teammates_per_round numeric(6,2),
    rounds_with_kills integer,
    kill_to_death_diff character varying(255),
    total_opening_kills integer,
    total_opening_deaths integer,
    opening_kill_ratio numeric(4,2),
    opening_kill_rating numeric(4,2),
    team_win_percent_after_first_kill character varying(7),
    first_kill_in_won_rounds character varying(7),
    zero_kill_rounds integer,
    one_kill_rounds integer,
    two_kill_rounds integer,
    three_kill_rounds integer,
    four_kill_rounds integer,
    five_kill_rounds integer,
    rifle_kills integer,
    sniper_kills integer,
    smg_kills integer,
    pistol_kills integer,
    grenade_kills integer,
    other_kills integer,
    rating numeric(4,2)
);


ALTER TABLE etl.playerstat_source3_extract OWNER TO comacrae;

--
-- Name: playerstat_source3_transform; Type: TABLE; Schema: etl; Owner: postgres
--

CREATE TABLE etl.playerstat_source3_transform (
    player_id integer,
    nickname character varying(255),
    real_name character varying(255),
    age integer,
    country character varying(255),
    current_team character varying(255),
    teams text,
    total_kills integer,
    total_deaths integer,
    headshot_percentage numeric(5,2),
    damage_per_round numeric(6,2),
    grenade_dmg_per_round numeric(6,2),
    maps_played integer,
    rounds_played integer,
    kills_per_death numeric(6,2),
    kills_per_round numeric(6,2),
    assists_per_round numeric(6,2),
    deaths_per_round numeric(6,2),
    saved_by_teammate_per_round numeric(6,2),
    saved_teammates_per_round numeric(6,2),
    rounds_with_kills integer,
    total_opening_kills integer,
    total_opening_deaths integer,
    opening_kill_ratio numeric(4,2),
    opening_kill_rating numeric(4,2),
    team_win_percent_after_first_kill numeric(5,2),
    first_kill_in_won_rounds numeric(5,2),
    zero_kill_rounds integer,
    one_kill_rounds integer,
    two_kill_rounds integer,
    three_kill_rounds integer,
    four_kill_rounds integer,
    five_kill_rounds integer,
    rifle_kills integer,
    sniper_kills integer,
    smg_kills integer,
    pistol_kills integer,
    grenade_kills integer,
    other_kills integer,
    rating numeric(4,2)
);


ALTER TABLE etl.playerstat_source3_transform OWNER TO postgres;

--
-- Name: teamstat_extract; Type: TABLE; Schema: etl; Owner: postgres
--

CREATE TABLE etl.teamstat_extract (
    idx integer,
    name character varying(255),
    country character varying(255),
    total_maps integer,
    kd_diff integer,
    kd numeric(4,2),
    rating numeric(4,2)
);


ALTER TABLE etl.teamstat_extract OWNER TO postgres;

--
-- Name: full_data; Type: TABLE; Schema: players; Owner: postgres
--

CREATE TABLE players.full_data (
    player character varying(255),
    real_name character varying(255),
    age integer,
    country character varying(255),
    maps_played integer,
    rounds_played integer,
    current_team character varying(255),
    teams text,
    total_kills integer,
    total_deaths integer,
    kill_death_ratio numeric(6,2),
    headshot_percentage numeric(5,2),
    damage_per_round numeric(6,2),
    grenade_dmg_per_round numeric(6,2),
    kills_per_round numeric(6,2),
    assists_per_round numeric(6,2),
    deaths_per_round numeric(6,2),
    saved_by_teammate_per_round numeric(6,2),
    saved_teammates_per_round numeric(6,2),
    rounds_with_kills integer,
    zero_kill_rounds integer,
    one_kill_rounds integer,
    two_kill_rounds integer,
    three_kill_rounds integer,
    four_kill_rounds integer,
    five_kill_rounds integer,
    percent_rounds_kast numeric(4,2),
    total_opening_kills integer,
    total_opening_deaths integer,
    opening_kill_ratio numeric(4,2),
    opening_kill_rating numeric(4,2),
    team_win_percent_after_first_kill numeric(5,2),
    first_kill_in_won_rounds numeric(5,2),
    rifle_kills integer,
    sniper_kills integer,
    smg_kills integer,
    pistol_kills integer,
    grenade_kills integer,
    other_kills integer,
    rating numeric(4,2),
    impact numeric(4,2)
);


ALTER TABLE players.full_data OWNER TO postgres;

--
-- Name: general; Type: TABLE; Schema: players; Owner: postgres
--

CREATE TABLE players.general (
    player character varying(255),
    real_name character varying(255),
    age integer,
    country character varying(255),
    maps_played integer,
    rounds_played integer
);


ALTER TABLE players.general OWNER TO postgres;

--
-- Name: performance_benchmarks; Type: TABLE; Schema: players; Owner: postgres
--

CREATE TABLE players.performance_benchmarks (
    player character varying(255),
    rating numeric(4,2),
    impact numeric(4,2)
);


ALTER TABLE players.performance_benchmarks OWNER TO postgres;

--
-- Name: performance_general; Type: TABLE; Schema: players; Owner: postgres
--

CREATE TABLE players.performance_general (
    player character varying(255),
    total_kills integer,
    total_deaths integer,
    kill_death_ratio numeric(6,2),
    headshot_percentage numeric(5,2)
);


ALTER TABLE players.performance_general OWNER TO postgres;

--
-- Name: performance_general_avg; Type: VIEW; Schema: players; Owner: postgres
--

CREATE VIEW players.performance_general_avg AS
 SELECT (avg(kill_death_ratio))::numeric(4,2) AS kill_death_ratio,
    (avg(total_kills))::numeric(10,2) AS total_kills,
    (avg(total_deaths))::numeric(10,2) AS total_deaths,
    (avg(headshot_percentage))::numeric(4,2) AS headshot_percentage
   FROM players.performance_general;


ALTER VIEW players.performance_general_avg OWNER TO postgres;

--
-- Name: performance_opening; Type: TABLE; Schema: players; Owner: postgres
--

CREATE TABLE players.performance_opening (
    player character varying(255),
    total_opening_kills integer,
    total_opening_deaths integer,
    opening_kill_ratio numeric(4,2),
    opening_kill_rating numeric(4,2),
    team_win_percent_after_first_kill numeric(5,2),
    first_kill_in_won_rounds numeric(5,2)
);


ALTER TABLE players.performance_opening OWNER TO postgres;

--
-- Name: performance_roundwise; Type: TABLE; Schema: players; Owner: postgres
--

CREATE TABLE players.performance_roundwise (
    player character varying(255),
    damage_per_round numeric(6,2),
    grenade_dmg_per_round numeric(6,2),
    kills_per_round numeric(6,2),
    assists_per_round numeric(6,2),
    deaths_per_round numeric(6,2),
    saved_by_teammate_per_round numeric(6,2),
    saved_teammates_per_round numeric(6,2),
    rounds_with_kills integer,
    zero_kill_rounds integer,
    one_kill_rounds integer,
    two_kill_rounds integer,
    three_kill_rounds integer,
    four_kill_rounds integer,
    five_kill_rounds integer,
    percent_rounds_kast numeric(4,2)
);


ALTER TABLE players.performance_roundwise OWNER TO postgres;

--
-- Name: performance_weapons; Type: TABLE; Schema: players; Owner: postgres
--

CREATE TABLE players.performance_weapons (
    player character varying(255),
    rifle_kills integer,
    sniper_kills integer,
    smg_kills integer,
    pistol_kills integer,
    grenade_kills integer,
    other_kills integer
);


ALTER TABLE players.performance_weapons OWNER TO postgres;

--
-- Name: player_rating_by_country; Type: VIEW; Schema: players; Owner: postgres
--

CREATE VIEW players.player_rating_by_country AS
 WITH avg_country_rating AS (
         SELECT a.player,
            b.rating AS player_rating,
            a.country,
            count(a.country) OVER (PARTITION BY a.country ORDER BY a.country) AS players_per_country,
            avg(b.rating) OVER (PARTITION BY a.country ORDER BY a.country) AS country_avg
           FROM (players.general a
             JOIN ( SELECT performance_benchmarks.player,
                    performance_benchmarks.rating
                   FROM players.performance_benchmarks) b ON (((a.player)::text = (b.player)::text)))
        ), country_ranking AS (
         SELECT avg_country_rating.player,
            avg_country_rating.player_rating,
            ((avg_country_rating.player_rating - avg_country_rating.country_avg))::numeric(4,2) AS performance_over_country_avg,
            avg_country_rating.country,
            dense_rank() OVER (PARTITION BY avg_country_rating.country ORDER BY avg_country_rating.player_rating DESC) AS player_rank_by_country,
            (avg_country_rating.country_avg)::numeric(4,2) AS country_avg_rating,
            avg_country_rating.players_per_country
           FROM avg_country_rating
          ORDER BY avg_country_rating.country, (dense_rank() OVER (PARTITION BY avg_country_rating.country ORDER BY avg_country_rating.player_rating DESC))
        )
 SELECT player,
    player_rating,
    performance_over_country_avg,
    country,
    (((player_rank_by_country)::text || '/'::text) || (players_per_country)::text) AS player_rank_by_country
   FROM country_ranking;


ALTER VIEW players.player_rating_by_country OWNER TO postgres;

--
-- Name: player_team_current; Type: TABLE; Schema: players; Owner: postgres
--

CREATE TABLE players.player_team_current (
    player character varying(255),
    current_team character varying(255)
);


ALTER TABLE players.player_team_current OWNER TO postgres;

--
-- Name: player_team_history; Type: TABLE; Schema: players; Owner: postgres
--

CREATE TABLE players.player_team_history (
    player character varying(255),
    teams text
);


ALTER TABLE players.player_team_history OWNER TO postgres;

--
-- Name: full_data; Type: TABLE; Schema: teams; Owner: postgres
--

CREATE TABLE teams.full_data (
    name character varying(255),
    country character varying(255),
    total_maps integer,
    kd_diff integer,
    kd numeric(4,2),
    rating numeric(4,2)
);


ALTER TABLE teams.full_data OWNER TO postgres;

--
-- Name: general; Type: TABLE; Schema: teams; Owner: postgres
--

CREATE TABLE teams.general (
    name character varying(255),
    country character varying(255),
    total_maps integer
);


ALTER TABLE teams.general OWNER TO postgres;

--
-- Name: performance; Type: TABLE; Schema: teams; Owner: postgres
--

CREATE TABLE teams.performance (
    name character varying(255),
    kd_diff integer,
    kd numeric(4,2),
    rating numeric(4,2)
);


ALTER TABLE teams.performance OWNER TO postgres;

--
-- Data for Name: playerstat_source1_extract; Type: TABLE DATA; Schema: etl; Owner: postgres
--

COPY etl.playerstat_source1_extract (idx, name, country, teams, total_maps, total_rounds, kd_diff, kd, rating) FROM stdin;
\.
COPY etl.playerstat_source1_extract (idx, name, country, teams, total_maps, total_rounds, kd_diff, kd, rating) FROM '$$PATH$$/4975.dat';

--
-- Data for Name: playerstat_source1_transform; Type: TABLE DATA; Schema: etl; Owner: postgres
--

COPY etl.playerstat_source1_transform (player, country, teams, total_maps, total_rounds, kd_diff, kd, rating) FROM stdin;
\.
COPY etl.playerstat_source1_transform (player, country, teams, total_maps, total_rounds, kd_diff, kd, rating) FROM '$$PATH$$/4976.dat';

--
-- Data for Name: playerstat_source2_extract; Type: TABLE DATA; Schema: etl; Owner: postgres
--

COPY etl.playerstat_source2_extract (nick, country, stats_link, teams, maps_played, rounds_played, kd_difference, kd_ratio, rating, total_kills, headshot_percentage, total_deaths, grenade_damage_per_round, kills_per_round, assists_per_round, deaths_per_round, teammate_saved_per_round, saved_by_teammate_per_round, kast, impact) FROM stdin;
\.
COPY etl.playerstat_source2_extract (nick, country, stats_link, teams, maps_played, rounds_played, kd_difference, kd_ratio, rating, total_kills, headshot_percentage, total_deaths, grenade_damage_per_round, kills_per_round, assists_per_round, deaths_per_round, teammate_saved_per_round, saved_by_teammate_per_round, kast, impact) FROM '$$PATH$$/4974.dat';

--
-- Data for Name: playerstat_source2_transform; Type: TABLE DATA; Schema: etl; Owner: postgres
--

COPY etl.playerstat_source2_transform (player, country, teams, maps_played, rounds_played, kd_difference, kd_ratio, rating, total_kills, headshot_percentage, total_deaths, grenade_damage_per_round, kills_per_round, assists_per_round, deaths_per_round, teammate_saved_per_round, saved_by_teammate_per_round, kast, impact) FROM stdin;
\.
COPY etl.playerstat_source2_transform (player, country, teams, maps_played, rounds_played, kd_difference, kd_ratio, rating, total_kills, headshot_percentage, total_deaths, grenade_damage_per_round, kills_per_round, assists_per_round, deaths_per_round, teammate_saved_per_round, saved_by_teammate_per_round, kast, impact) FROM '$$PATH$$/4977.dat';

--
-- Data for Name: playerstat_source3_extract; Type: TABLE DATA; Schema: etl; Owner: comacrae
--

COPY etl.playerstat_source3_extract (player_id, nickname, real_name, age, country, current_team, teams, total_kills, total_deaths, headshot_percentage, damage_per_round, grenade_dmg_per_round, maps_played, rounds_played, kills_per_death, kills_per_round, assists_per_round, deaths_per_round, saved_by_teammate_per_round, saved_teammates_per_round, rounds_with_kills, kill_to_death_diff, total_opening_kills, total_opening_deaths, opening_kill_ratio, opening_kill_rating, team_win_percent_after_first_kill, first_kill_in_won_rounds, zero_kill_rounds, one_kill_rounds, two_kill_rounds, three_kill_rounds, four_kill_rounds, five_kill_rounds, rifle_kills, sniper_kills, smg_kills, pistol_kills, grenade_kills, other_kills, rating) FROM stdin;
\.
COPY etl.playerstat_source3_extract (player_id, nickname, real_name, age, country, current_team, teams, total_kills, total_deaths, headshot_percentage, damage_per_round, grenade_dmg_per_round, maps_played, rounds_played, kills_per_death, kills_per_round, assists_per_round, deaths_per_round, saved_by_teammate_per_round, saved_teammates_per_round, rounds_with_kills, kill_to_death_diff, total_opening_kills, total_opening_deaths, opening_kill_ratio, opening_kill_rating, team_win_percent_after_first_kill, first_kill_in_won_rounds, zero_kill_rounds, one_kill_rounds, two_kill_rounds, three_kill_rounds, four_kill_rounds, five_kill_rounds, rifle_kills, sniper_kills, smg_kills, pistol_kills, grenade_kills, other_kills, rating) FROM '$$PATH$$/4973.dat';

--
-- Data for Name: playerstat_source3_transform; Type: TABLE DATA; Schema: etl; Owner: postgres
--

COPY etl.playerstat_source3_transform (player_id, nickname, real_name, age, country, current_team, teams, total_kills, total_deaths, headshot_percentage, damage_per_round, grenade_dmg_per_round, maps_played, rounds_played, kills_per_death, kills_per_round, assists_per_round, deaths_per_round, saved_by_teammate_per_round, saved_teammates_per_round, rounds_with_kills, total_opening_kills, total_opening_deaths, opening_kill_ratio, opening_kill_rating, team_win_percent_after_first_kill, first_kill_in_won_rounds, zero_kill_rounds, one_kill_rounds, two_kill_rounds, three_kill_rounds, four_kill_rounds, five_kill_rounds, rifle_kills, sniper_kills, smg_kills, pistol_kills, grenade_kills, other_kills, rating) FROM stdin;
\.
COPY etl.playerstat_source3_transform (player_id, nickname, real_name, age, country, current_team, teams, total_kills, total_deaths, headshot_percentage, damage_per_round, grenade_dmg_per_round, maps_played, rounds_played, kills_per_death, kills_per_round, assists_per_round, deaths_per_round, saved_by_teammate_per_round, saved_teammates_per_round, rounds_with_kills, total_opening_kills, total_opening_deaths, opening_kill_ratio, opening_kill_rating, team_win_percent_after_first_kill, first_kill_in_won_rounds, zero_kill_rounds, one_kill_rounds, two_kill_rounds, three_kill_rounds, four_kill_rounds, five_kill_rounds, rifle_kills, sniper_kills, smg_kills, pistol_kills, grenade_kills, other_kills, rating) FROM '$$PATH$$/4978.dat';

--
-- Data for Name: teamstat_extract; Type: TABLE DATA; Schema: etl; Owner: postgres
--

COPY etl.teamstat_extract (idx, name, country, total_maps, kd_diff, kd, rating) FROM stdin;
\.
COPY etl.teamstat_extract (idx, name, country, total_maps, kd_diff, kd, rating) FROM '$$PATH$$/4987.dat';

--
-- Data for Name: full_data; Type: TABLE DATA; Schema: players; Owner: postgres
--

COPY players.full_data (player, real_name, age, country, maps_played, rounds_played, current_team, teams, total_kills, total_deaths, kill_death_ratio, headshot_percentage, damage_per_round, grenade_dmg_per_round, kills_per_round, assists_per_round, deaths_per_round, saved_by_teammate_per_round, saved_teammates_per_round, rounds_with_kills, zero_kill_rounds, one_kill_rounds, two_kill_rounds, three_kill_rounds, four_kill_rounds, five_kill_rounds, percent_rounds_kast, total_opening_kills, total_opening_deaths, opening_kill_ratio, opening_kill_rating, team_win_percent_after_first_kill, first_kill_in_won_rounds, rifle_kills, sniper_kills, smg_kills, pistol_kills, grenade_kills, other_kills, rating, impact) FROM stdin;
\.
COPY players.full_data (player, real_name, age, country, maps_played, rounds_played, current_team, teams, total_kills, total_deaths, kill_death_ratio, headshot_percentage, damage_per_round, grenade_dmg_per_round, kills_per_round, assists_per_round, deaths_per_round, saved_by_teammate_per_round, saved_teammates_per_round, rounds_with_kills, zero_kill_rounds, one_kill_rounds, two_kill_rounds, three_kill_rounds, four_kill_rounds, five_kill_rounds, percent_rounds_kast, total_opening_kills, total_opening_deaths, opening_kill_ratio, opening_kill_rating, team_win_percent_after_first_kill, first_kill_in_won_rounds, rifle_kills, sniper_kills, smg_kills, pistol_kills, grenade_kills, other_kills, rating, impact) FROM '$$PATH$$/4981.dat';

--
-- Data for Name: general; Type: TABLE DATA; Schema: players; Owner: postgres
--

COPY players.general (player, real_name, age, country, maps_played, rounds_played) FROM stdin;
\.
COPY players.general (player, real_name, age, country, maps_played, rounds_played) FROM '$$PATH$$/4982.dat';

--
-- Data for Name: performance_benchmarks; Type: TABLE DATA; Schema: players; Owner: postgres
--

COPY players.performance_benchmarks (player, rating, impact) FROM stdin;
\.
COPY players.performance_benchmarks (player, rating, impact) FROM '$$PATH$$/4986.dat';

--
-- Data for Name: performance_general; Type: TABLE DATA; Schema: players; Owner: postgres
--

COPY players.performance_general (player, total_kills, total_deaths, kill_death_ratio, headshot_percentage) FROM stdin;
\.
COPY players.performance_general (player, total_kills, total_deaths, kill_death_ratio, headshot_percentage) FROM '$$PATH$$/4991.dat';

--
-- Data for Name: performance_opening; Type: TABLE DATA; Schema: players; Owner: postgres
--

COPY players.performance_opening (player, total_opening_kills, total_opening_deaths, opening_kill_ratio, opening_kill_rating, team_win_percent_after_first_kill, first_kill_in_won_rounds) FROM stdin;
\.
COPY players.performance_opening (player, total_opening_kills, total_opening_deaths, opening_kill_ratio, opening_kill_rating, team_win_percent_after_first_kill, first_kill_in_won_rounds) FROM '$$PATH$$/4984.dat';

--
-- Data for Name: performance_roundwise; Type: TABLE DATA; Schema: players; Owner: postgres
--

COPY players.performance_roundwise (player, damage_per_round, grenade_dmg_per_round, kills_per_round, assists_per_round, deaths_per_round, saved_by_teammate_per_round, saved_teammates_per_round, rounds_with_kills, zero_kill_rounds, one_kill_rounds, two_kill_rounds, three_kill_rounds, four_kill_rounds, five_kill_rounds, percent_rounds_kast) FROM stdin;
\.
COPY players.performance_roundwise (player, damage_per_round, grenade_dmg_per_round, kills_per_round, assists_per_round, deaths_per_round, saved_by_teammate_per_round, saved_teammates_per_round, rounds_with_kills, zero_kill_rounds, one_kill_rounds, two_kill_rounds, three_kill_rounds, four_kill_rounds, five_kill_rounds, percent_rounds_kast) FROM '$$PATH$$/4983.dat';

--
-- Data for Name: performance_weapons; Type: TABLE DATA; Schema: players; Owner: postgres
--

COPY players.performance_weapons (player, rifle_kills, sniper_kills, smg_kills, pistol_kills, grenade_kills, other_kills) FROM stdin;
\.
COPY players.performance_weapons (player, rifle_kills, sniper_kills, smg_kills, pistol_kills, grenade_kills, other_kills) FROM '$$PATH$$/4985.dat';

--
-- Data for Name: player_team_current; Type: TABLE DATA; Schema: players; Owner: postgres
--

COPY players.player_team_current (player, current_team) FROM stdin;
\.
COPY players.player_team_current (player, current_team) FROM '$$PATH$$/4980.dat';

--
-- Data for Name: player_team_history; Type: TABLE DATA; Schema: players; Owner: postgres
--

COPY players.player_team_history (player, teams) FROM stdin;
\.
COPY players.player_team_history (player, teams) FROM '$$PATH$$/4979.dat';

--
-- Data for Name: full_data; Type: TABLE DATA; Schema: teams; Owner: postgres
--

COPY teams.full_data (name, country, total_maps, kd_diff, kd, rating) FROM stdin;
\.
COPY teams.full_data (name, country, total_maps, kd_diff, kd, rating) FROM '$$PATH$$/4988.dat';

--
-- Data for Name: general; Type: TABLE DATA; Schema: teams; Owner: postgres
--

COPY teams.general (name, country, total_maps) FROM stdin;
\.
COPY teams.general (name, country, total_maps) FROM '$$PATH$$/4989.dat';

--
-- Data for Name: performance; Type: TABLE DATA; Schema: teams; Owner: postgres
--

COPY teams.performance (name, kd_diff, kd, rating) FROM stdin;
\.
COPY teams.performance (name, kd_diff, kd, rating) FROM '$$PATH$$/4990.dat';

--
-- Name: playerstat_source3_extract playerstat_source3_load_pkey; Type: CONSTRAINT; Schema: etl; Owner: comacrae
--

ALTER TABLE ONLY etl.playerstat_source3_extract
    ADD CONSTRAINT playerstat_source3_load_pkey PRIMARY KEY (player_id);


--
-- PostgreSQL database dump complete
--

